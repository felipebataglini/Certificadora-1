//Pacote
package bfm;

//Importações
import Login.GerenciadorLogin;

/**
 *
 * @author Felipe
 */
public class BFM {
    public static void main(String[] args) {
        new GerenciadorLogin();
    }
}
