/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Escola;

/**
 *
 * @author Felipe
 */
public class Escola{
    private int idescola;
    private String nome;
    private String endereco;
    private String responsavel;
    private String email;
    private long telefone;

    public int getIDEscola() {
        return idescola;
    }
    public void setIDEscola(int idescola) {
        this.idescola = idescola;
    }

    public int getIdescola() {
        return idescola;
    }
    public void setIdescola(int idescola) {
        this.idescola = idescola;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getResponsavel() {
        return responsavel;
    }
    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public long getTelefone() {
        return telefone;
    }
    public void setTelefone(long telefone) {
        this.telefone = telefone;
    }
}
