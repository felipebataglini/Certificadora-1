/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Doacao;

/**
 *
 * @author Felipe
 */
public class Doacao {
    private int iddoacao;
    private String data;
    private int idescola;
    private int idvoluntario;
    private int idproduto;

    public int getIddoacao() {
        return iddoacao;
    }
    public void setIddoacao(int iddoacao) {
        this.iddoacao = iddoacao;
    }

    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }

    public int getIdescola() {
        return idescola;
    }
    public void setIdescola(int idescola) {
        this.idescola = idescola;
    }

    public int getIdvoluntario() {
        return idvoluntario;
    }
    public void setIdvoluntario(int idvoluntario) {
        this.idvoluntario = idvoluntario;
    }

    public int getIdproduto() {
        return idproduto;
    }
    public void setIdproduto(int idproduto) {
        this.idproduto = idproduto;
    }
}
